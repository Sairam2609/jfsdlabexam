package com.klef.jfsd.exam;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
public class ClientDemo {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        try {
            Transaction transaction = session.beginTransaction();
            insertProjects(session);
            performAggregateFunctions(session);
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
            sessionFactory.close();
        }
    }
    private static void insertProjects(Session session) {
        Project p1 = new Project();
        p1.setProjectName("Jfsd lab project");
        p1.setDuration(5);
        p1.setBudget(500);
        p1.setTeamLead("sairam");
        Project p2 = new Project();
        p2.setProjectName("mern project");
        p2.setDuration(5);
        p2.setBudget(200);
        p2.setTeamLead("klu");

        Project p3 = new Project();
        p3.setProjectName("python project");
        p3.setDuration(5);
        p3.setBudget(300);
        p3.setTeamLead("klef");

        session.save(p1);
        session.save(p2);
        session.save(p3);

        System.out.println("Projects inserted successfully.");
    }

    private static void performAggregateFunctions(Session session) {
        Criteria criteria = session.createCriteria(Project.class);

        criteria.setProjection(Projections.rowCount());
        long count = (Long) criteria.uniqueResult();
        System.out.println("Total Projects: " + count);

        criteria.setProjection(Projections.max("budget"));
        double maxBudget = (Double) criteria.uniqueResult();
        System.out.println("Maximum Budget: " + maxBudget);

        criteria.setProjection(Projections.min("budget"));
        double minBudget = (Double) criteria.uniqueResult();
        System.out.println("Minimum Budget: " + minBudget);

        criteria.setProjection(Projections.sum("budget"));
        double sumBudget = (Double) criteria.uniqueResult();
        System.out.println("Total Budget: " + sumBudget);

        criteria.setProjection(Projections.avg("budget"));
        double avgBudget = (Double) criteria.uniqueResult();
        System.out.println("Average Budget: " + avgBudget);
    }
}
